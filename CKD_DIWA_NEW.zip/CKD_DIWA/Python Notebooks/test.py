

from tensorflow import keras
dd = keras.models.load_model('ckd.model')
##[['age','bp','al','sg','sc','sod','hemo','appet']]
out=dd.predict([[33.0, 80.0, 0.0, 1.025, 1.1, 1441.0, 15.0, 1.0]])
print(int(out[0][0]))

if int(out[0][0])==1:
    print("not ckd")
else:
    print("ckd")


