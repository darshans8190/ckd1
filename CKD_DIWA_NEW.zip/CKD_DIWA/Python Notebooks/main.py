import pandas as pd
import os
from flask import Flask, render_template, url_for, flash, redirect, request
dataset = pd.read_csv('data.csv')
dataset = dataset.drop(['Unnamed: 25'],axis=1)
dataset = dataset.fillna(dataset.mean())
dataset = dataset.dropna()

from sklearn.metrics import accuracy_score
from sklearn.preprocessing import LabelEncoder
le = LabelEncoder()

RBC = le.fit_transform(dataset.RBC)
PC = le.fit_transform(dataset.PC)
PCC = le.fit_transform(dataset.PCC)
BA = le.fit_transform(dataset.BA)
HTN = le.fit_transform(dataset.HTN)
DM = le.fit_transform(dataset.DM)
CAD = le.fit_transform(dataset.CAD)
APPET = le.fit_transform(dataset.APPET)
Pe = le.fit_transform(dataset.Pe)
Ane = le.fit_transform(dataset.Ane)
class1 = le.fit_transform(dataset.class1)

testing=dataset
print(testing)

testing['RBC'] = RBC
testing['PC'] = PC
testing['PCC'] = PCC
testing['BA'] = BA
testing['HTN'] = HTN
testing['DM'] = DM
testing['CAD'] = CAD
testing['APPET'] = APPET
testing['Pe'] = Pe
testing['Ane'] = Ane
testing['class1'] = class1

X = testing.drop(['SG','RBC','PC','PCC','BA','BGR','Bu','POT','PCV','WC','RC','HTN','DM','CAD','Pe','Ane','class1'],axis=1)
y = testing.iloc[:, 24].values
print("x",X)
print("y",y)

# def is_float(input):
#   try:
#     num = float(input)
#   except ValueError:
#     return False
#   return True
#
# for i in range(0,184):
#     if y[i] == 'ckd':
#         y[i] = 1
#     else:
#         y[i] = 0
# y = y.astype(int)
# print("y",y)

from sklearn.model_selection import train_test_split
X_train,X_test,y_train,y_test=train_test_split(X,y,test_size=0.33,random_state=100)

from sklearn.ensemble import RandomForestClassifier

max_accuracy = 0

#for x in range(2000):
rf = RandomForestClassifier(random_state=100)
rf.fit(X_train, y_train)
Y_pred_rf = rf.predict(X_test)
print("y",Y_pred_rf)
current_accuracy = round(accuracy_score(Y_pred_rf, y_test) * 100, 2)
if (current_accuracy > max_accuracy):
   max_accuracy = current_accuracy
   best_x = 100

# print(max_accuracy)
# print(best_x)

rf = RandomForestClassifier(random_state=best_x)
rf.fit(X_train, y_train)
Y_pred_rf = rf.predict(X_test)
print("ypred",Y_pred_rf)


print(accuracy_score(y_test, Y_pred_rf)*100)

import sqlite3
conn = sqlite3.connect('cronic_database')
cur = conn.cursor()
try:
   cur.execute('''CREATE TABLE user (
     name varchar(20) DEFAULT NULL,
      email varchar(50) DEFAULT NULL,
     password varchar(20) DEFAULT NULL,
     gender varchar(10) DEFAULT NULL,
     age int(11) DEFAULT NULL
   )''')

except:
   pass

from flask import Flask, render_template, url_for,request, flash, redirect, session
app = Flask(__name__)
app.config['SECRET_KEY'] = '881e69e15e7a528830975467b9d87a98'

@app.route('/user_login',methods = ['POST', 'GET'])
def user_login():
   conn = sqlite3.connect('cronic_database')
   cur = conn.cursor()
   if request.method == 'POST':
      email = request.form['email']
      password = request.form['psw']
      print('asd')
      count = cur.execute('SELECT * FROM user WHERE email = "%s" AND password = "%s"' % (email, password))
      print(count)
      #conn.commit()
      #cur.close()
      l = len(cur.fetchall())
      if l > 0:
         flash( f'Successfully Logged in' )
         return render_template('user_account.html')
      else:
         print('hello')
         flash( f'Invalid Email and Password!' )
   return render_template('user_login.html')


@app.route('/user_register',methods = ['POST', 'GET'])
def user_register():
   conn = sqlite3.connect('cronic_database')
   cur = conn.cursor()
   if request.method == 'POST':
      name = request.form['uname']
      email = request.form['email']
      password = request.form['psw']
      gender = request.form['gender']
      age = request.form['age']

      cur.execute("insert into user(name,email,password,gender,age) values ('%s','%s','%s','%s','%s')" % (name, email, password, gender, age))
      conn.commit()
      # cur.close()
      print('data inserted')
      return redirect(url_for('user_login'))

   return render_template('user_register.html')

@app.route('/user_account',methods = ['POST', 'GET'])
def user_account():
   return render_template('user_account.html')


@app.route('/predict', methods=['POST', 'GET'])
def predict():
    age = request.form['age']
    blood_pre = request.form['bloodpressure']
    # blood = str(blood_pre)
    print("blood",blood_pre)
    al = request.form['al']
    bloodsugar = request.form['serum_creatinine']
    serum_creatinine = request.form['serum_creatinine']
    sodium = request.form['sodium']
    appetite = request.form['appetite']
    hemogloabin = request.form['hemogloabin']
    global rf
    if request.method == 'POST':
       my_prediction = rf.predict([[float(age),float(blood_pre),
                                    float(al),float(bloodsugar),
                                    float(serum_creatinine),float(sodium),
                                    float(hemogloabin),float(appetite)]])
       print("pred",my_prediction)
       if 0 == my_prediction[0]:
          # flash('disease detected')
          if int(blood_pre) >= 60 and int(appetite) == 0 and float(hemogloabin) < 9.9:
              return render_template('stage4.html')
          elif int(blood_pre) >= 60 and int(appetite) == 0:
              return render_template('stage3.html')
          elif int(appetite) == 0:
              return render_template('stage2.html')
          elif int(blood_pre) >= 60:
              return render_template('stage1.html')
       else:
          flash('you dont have disease , u can eat everything ')
    return render_template('user_account.html')
@app.route('/stage1')
def stage1():
   return render_template('stage1.html')
@app.route('/stage2')
def stage2():
   return render_template('stage2.html')
@app.route('/stage3')
def stage3():
   return render_template('stage3.html')
@app.route('/stage4')
def stage4():
   return render_template('stage4.html')


@app.route('/')
@app.route('/home')
def home():
   if not session.get('logged_in'):
      return render_template('home.html')
   else:
      return redirect(url_for('user_account'))

@app.route('/home1')
def home1():
   if not session.get('logged_in'):
      return render_template('home1.html')
   else:
      return redirect(url_for('user_account'))

@app.route("/logout")
def logout():
   session['logged_in'] = False
   return home()

@app.route("/logoutd",methods = ['POST','GET'])
def logoutd():
   return home()

@app.route("/about")
def about():
   return render_template('about.html')

if __name__ == '__main__':
   app.secret_key = os.urandom(12)
   app.run(debug=True)