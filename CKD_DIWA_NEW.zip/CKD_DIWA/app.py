from flask import Flask, render_template, request, flash, redirect
from tensorflow.keras.models import load_model
import sqlite3
from tensorflow import keras
from tensorflow import keras
dd = keras.models.load_model('ckd.model')
import telepot
bot=telepot.Bot("7157392501:AAFcWZuvSwLUevhjrXM4jcNTR5oGrKaiqoQ")
ch_id="952860932"
app = Flask(__name__)

@app.route('/')
def home():
    return render_template('home.html')

@app.route('/index')
def index():
    return render_template('index.html')

@app.route('/userlog', methods=['GET', 'POST'])
def userlog():
    if request.method == 'POST':

        connection = sqlite3.connect('user_data.db')
        cursor = connection.cursor()

        name = request.form['name']
        password = request.form['password']

        query = "SELECT name, password FROM user WHERE name = '"+name+"' AND password= '"+password+"'"
        cursor.execute(query)

        result = cursor.fetchall()

        if len(result) == 0:
            return render_template('index.html', msg='Sorry, Incorrect Credentials Provided,  Try Again')
        else:
            return render_template('kidney.html')

    return render_template('index.html')


@app.route('/userreg', methods=['GET', 'POST'])
def userreg():
    if request.method == 'POST':

        connection = sqlite3.connect('user_data.db')
        cursor = connection.cursor()

        name = request.form['name']
        password = request.form['password']
        mobile = request.form['phone']
        email = request.form['email']
        
        print(name, mobile, email, password)

        command = """CREATE TABLE IF NOT EXISTS user(name TEXT, password TEXT, mobile TEXT, email TEXT)"""
        cursor.execute(command)

        cursor.execute("INSERT INTO user VALUES ('"+name+"', '"+password+"', '"+mobile+"', '"+email+"')")
        connection.commit()

        return render_template('index.html', msg='Successfully Registered')
    
    return render_template('index.html')

@app.route('/logout')
def logout():
    return render_template('index.html')


@app.route("/kidneyPage", methods=['GET', 'POST'])
def kidneyPage():
    return render_template('kidney.html')

@app.route('/stage1')
def stage1():
   return render_template('stage1.html')

@app.route('/stage2')
def stage2():
   return render_template('stage2.html')
@app.route('/stage3')
def stage3():
   return render_template('stage3.html')
@app.route('/stage4')
def stage4():
   return render_template('stage4.html')

@app.route("/predict", methods = ['POST', 'GET'])
def predict():
    if request.method == 'POST':
        name = request.form['name']
        age = float(request.form['age'])
        bp = float(request.form['bp'])
        al = float(request.form['al'])
        sg = float(request.form['sg'])
        sc = float(request.form['sc'])
        sod = float(request.form['sod'])
        hemo = float(request.form['hemo'])
        appet = float(request.form['appet'])
        
        res = dd.predict([[age,bp,al,sg,sc,sod,hemo,appet]])
        print(res)
        result = res[0][0]
        print(int(result))
        if int(result) ==1:
            if int(bp) >= 60 and int(appet) == 0 and float(hemo) < 9.9:
                stage=4
                status=""
                bot.sendMessage(ch_id,f"Name   : {name}  \n Age  : {age} \n Blood Pressure  : {bp} \n al : {al} \n sg  : {sg} \n sc  : {sc}  \n sod : {sod}  \n HEMO  : {hemo} \n\n Status  : Stage 4")
##                return render_template('stage4.html')
            elif int(bp) >= 60 and int(appet) == 0:
                stage=3
                status=""
                bot.sendMessage(ch_id,f"Name   : {name}  \n Age  : {age} \n Blood Pressure  : {bp} \n al : {al} \n sg  : {sg} \n sc  : {sc}  \n sod : {sod}  \n HEMO  : {hemo} \n\n Status  : Stage 3")
##                return render_template('stage3.html')
            
##                return render_template('stage2.html')
            elif int(bp) >= 60:
                stage=2
                status=""
                bot.sendMessage(ch_id,f"Name   : {name}  \n Age  : {age} \n Blood Pressure  : {bp} \n al : {al} \n sg  : {sg} \n sc  : {sc}  \n sod : {sod}  \n HEMO  : {hemo} \n\n Status  : Stage 1")
##                return render_template('stage1.html')
            else:
                stage=1
                status=""
                bot.sendMessage(ch_id,f"Name   : {name}  \n Age  : {age} \n Blood Pressure  : {bp} \n al : {al} \n sg  : {sg} \n sc  : {sc}  \n sod : {sod}  \n HEMO  : {hemo} \n\n Status  : Stage 2")
            print(stage)
            return render_template('predict.html', pred = result, name=name,status=status,stage=stage)
        else:
            stage=0
            status="You were Healthy ,Can Eat Anything u want"
            bot.sendMessage(ch_id,f"Name   : {name}  \n Age  : {age} \n Blood Pressure  : {bp} \n al : {al} \n sg  : {sg} \n sc  : {sc}  \n sod : {sod}  \n HEMO  : {hemo} \n\n Status  : Normal \n {stage}")
            
            
        # print("class  is {}".format(stage))

        return render_template('predict.html', pred = result, name=name,status=status,stage=stage)
       

    return render_template('predict.html')

if __name__ == '__main__':
	app.run(debug = True)
